import { AttendanceStatus } from "@prisma/client";

import { getMonthBounds, toDayBounds, toDateInput, toMonthInput } from "@/lib/attendance";
import { db } from "@/lib/db";

type AttendanceFilters = {
  schoolId: string;
  classId?: string;
  sectionId?: string;
  date?: string;
  month?: string;
};

type SaveAttendanceInput = {
  schoolId: string;
  academicYearId: string;
  classId: string;
  sectionId: string;
  date: string;
  entries: Array<{
    studentId: string;
    status: AttendanceStatus;
    remarks: string | null;
  }>;
};

export async function getAttendancePageData(filters: AttendanceFilters) {
  const classes = await db.schoolClass.findMany({
    where: { schoolId: filters.schoolId },
    orderBy: [{ displayOrder: "asc" }, { name: "asc" }]
  });

  const classId = filters.classId ?? classes[0]?.id ?? "";
  const sections = await db.section.findMany({
    where: {
      schoolId: filters.schoolId,
      ...(classId ? { classId } : {})
    },
    orderBy: { name: "asc" }
  });

  const sectionId = filters.sectionId ?? sections[0]?.id ?? "";
  const date = filters.date ?? toDateInput();
  const month = filters.month ?? toMonthInput();
  const selectedClass = classes.find((item) => item.id === classId) ?? classes[0];
  const selectedSection = sections.find((item) => item.id === sectionId) ?? sections[0];

  const students = selectedSection
    ? await db.student.findMany({
        where: {
          schoolId: filters.schoolId,
          classId: selectedClass.id,
          sectionId: selectedSection.id,
          status: { not: "ARCHIVED" }
        },
        orderBy: [{ rollNumber: "asc" }, { fullName: "asc" }]
      })
    : [];

  const dayBounds = toDayBounds(date);
  const monthBounds = getMonthBounds(month);
  const dayAttendances = students.length
    ? await db.attendance.findMany({
        where: {
          schoolId: filters.schoolId,
          studentId: { in: students.map((student) => student.id) },
          date: {
            gte: dayBounds.start,
            lte: dayBounds.end
          }
        }
      })
    : [];

  const monthlyAttendances = students.length
    ? await db.attendance.findMany({
        where: {
          schoolId: filters.schoolId,
          studentId: { in: students.map((student) => student.id) },
          date: {
            gte: monthBounds.start,
            lte: monthBounds.end
          }
        },
        orderBy: [{ date: "asc" }]
      })
    : [];

  return {
    classes,
    sections,
    selectedClass,
    selectedSection,
    students,
    dayAttendances,
    monthlyAttendances,
    date,
    month
  };
}

export async function saveAttendanceSheet(input: SaveAttendanceInput) {
  const students = await db.student.findMany({
    where: {
      schoolId: input.schoolId,
      classId: input.classId,
      sectionId: input.sectionId,
      status: { not: "ARCHIVED" }
    },
    orderBy: [{ rollNumber: "asc" }, { fullName: "asc" }],
    select: {
      id: true,
      fullName: true
    }
  });

  if (!students.length) {
    throw new Error("No active students are assigned to this section.");
  }

  const entryMap = new Map(input.entries.map((entry) => [entry.studentId, entry]));
  const bounds = toDayBounds(input.date);
  const auditEntries: Array<{
    attendanceId: string;
    studentId: string;
    fullName: string;
    action: string;
    status: AttendanceStatus;
    remarks: string | null;
  }> = [];

  await db.$transaction(async (tx) => {
    for (const student of students) {
      const entry = entryMap.get(student.id);
      const statusValue = entry?.status ?? AttendanceStatus.PRESENT;
      const remarks = entry?.remarks ?? null;
      const existing = await tx.attendance.findFirst({
        where: {
          schoolId: input.schoolId,
          academicYearId: input.academicYearId,
          studentId: student.id,
          date: {
            gte: bounds.start,
            lte: bounds.end
          }
        }
      });

      if (existing) {
        const updated = await tx.attendance.update({
          where: { id: existing.id },
          data: {
            status: statusValue,
            remarks
          }
        });

        auditEntries.push({
          attendanceId: updated.id,
          studentId: student.id,
          fullName: student.fullName,
          action: "attendance.updated",
          status: updated.status,
          remarks
        });
      } else {
        const created = await tx.attendance.create({
          data: {
            schoolId: input.schoolId,
            academicYearId: input.academicYearId,
            studentId: student.id,
            date: bounds.start,
            status: statusValue,
            remarks
          }
        });

        auditEntries.push({
          attendanceId: created.id,
          studentId: student.id,
          fullName: student.fullName,
          action: "attendance.marked",
          status: created.status,
          remarks
        });
      }
    }
  });

  return {
    studentsCount: students.length,
    auditEntries
  };
}
