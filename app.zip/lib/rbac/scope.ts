import { RoleCode } from "@prisma/client";

import { db } from "@/lib/db";
import type { ScopeContext } from "@/lib/rbac/types";

const ACADEMIC_STAFF_ROLES: RoleCode[] = [RoleCode.TEACHER, RoleCode.HOD, RoleCode.EXAM_CONTROLLER];

export function canAccessOwnData(context: ScopeContext, targetUserId: string) {
  return context.userId === targetUserId;
}

export async function canAccessStudent(context: ScopeContext, studentId: string) {
  if (context.roles.includes(RoleCode.SUPER_ADMIN) || context.roles.includes(RoleCode.ADMIN)) {
    return true;
  }

  if (context.roles.includes(RoleCode.STUDENT)) {
    return false;
  }

  if (context.roles.includes(RoleCode.PARENT)) {
    return parentCanAccessChild(context, studentId);
  }

  if (context.roles.some((role) => ACADEMIC_STAFF_ROLES.includes(role as RoleCode))) {
    return teacherCanAccessStudent(context, studentId);
  }

  const student = await db.student.findFirst({
    where: { id: studentId, schoolId: context.schoolId, isArchived: false },
    select: { id: true }
  });
  return Boolean(student);
}

export async function canAccessStaff(context: ScopeContext, staffId: string) {
  if (context.roles.includes(RoleCode.SUPER_ADMIN) || context.roles.includes(RoleCode.ADMIN) || context.roles.includes(RoleCode.HR)) {
    return true;
  }

  const ownStaff = await db.staff.findFirst({
    where: { id: staffId, schoolId: context.schoolId, userId: context.userId },
    select: { id: true }
  });
  return Boolean(ownStaff);
}

export async function canAccessClass(context: ScopeContext, classId: string) {
  if (context.roles.includes(RoleCode.SUPER_ADMIN) || context.roles.includes(RoleCode.ADMIN)) {
    return true;
  }

  if (context.roles.some((role) => ACADEMIC_STAFF_ROLES.includes(role as RoleCode))) {
    const staff = await db.staff.findFirst({
      where: {
        schoolId: context.schoolId,
        userId: context.userId,
        classTeacherFor: { some: { classId } }
      },
      select: { id: true }
    });
    return Boolean(staff);
  }

  if (context.roles.includes(RoleCode.STUDENT)) {
    return false;
  }

  if (context.roles.includes(RoleCode.PARENT)) {
    const match = await db.studentGuardian.findFirst({
      where: {
        parent: { schoolId: context.schoolId, userId: context.userId },
        student: { classId }
      },
      select: { id: true }
    });
    return Boolean(match);
  }

  return false;
}

export async function canAccessSection(context: ScopeContext, sectionId: string) {
  if (context.roles.includes(RoleCode.SUPER_ADMIN) || context.roles.includes(RoleCode.ADMIN)) {
    return true;
  }

  if (context.roles.includes(RoleCode.STUDENT)) {
    return false;
  }

  if (context.roles.includes(RoleCode.PARENT)) {
    const match = await db.studentGuardian.findFirst({
      where: {
        parent: { schoolId: context.schoolId, userId: context.userId },
        student: { sectionId }
      },
      select: { id: true }
    });
    return Boolean(match);
  }

  return false;
}

export async function parentCanAccessChild(context: ScopeContext, studentId: string) {
  if (!context.roles.includes(RoleCode.PARENT)) {
    return false;
  }

  const match = await db.studentGuardian.findFirst({
    where: {
      parent: { schoolId: context.schoolId, userId: context.userId },
      studentId
    },
    select: { id: true }
  });
  return Boolean(match);
}

export async function teacherCanAccessAssignedClass(context: ScopeContext, classId: string) {
  if (!context.roles.some((role) => ACADEMIC_STAFF_ROLES.includes(role as RoleCode))) {
    return false;
  }

  const assignment = await db.staff.findFirst({
    where: {
      schoolId: context.schoolId,
      userId: context.userId,
      classTeacherFor: { some: { classId } }
    },
    select: { id: true }
  });
  return Boolean(assignment);
}

export async function teacherCanAccessStudent(context: ScopeContext, studentId: string) {
  if (!context.roles.some((role) => ACADEMIC_STAFF_ROLES.includes(role as RoleCode))) {
    return false;
  }

  const student = await db.student.findFirst({
    where: { id: studentId, schoolId: context.schoolId },
    select: { classId: true }
  });

  if (!student?.classId) {
    return false;
  }

  return teacherCanAccessAssignedClass(context, student.classId);
}
