"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell,
  BookOpenCheck,
  CalendarCheck2,
  ClipboardList,
  History,
  FileText,
  IndianRupee,
  LayoutDashboard,
  LogOut,
  Menu,
  MonitorSmartphone,
  School,
  Settings2,
  Shield,
  UserCog,
  UserRound,
  Users,
  X
} from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";

import { logoutAction } from "@/lib/auth/actions";
import { Button } from "@/components/ui/button";
import { NAV_ITEMS } from "@/lib/copy";
import { cn } from "@/lib/utils";

type AppShellProps = {
  roleSummary: string;
  schoolName: string;
  userLabel: string;
  children: ReactNode;
};

export function AppShell({ roleSummary, schoolName, userLabel, children }: AppShellProps) {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const currentItem = useMemo(
    () =>
      NAV_ITEMS.find((item) =>
        item.href === "/dashboard" ? pathname === item.href : pathname.startsWith(item.href)
      ) ?? NAV_ITEMS[0],
    [pathname]
  );

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="mx-auto grid min-h-screen max-w-[1600px] lg:grid-cols-[256px_minmax(0,1fr)] xl:grid-cols-[268px_minmax(0,1fr)]">
        <div
          className={cn(
            "fixed inset-0 z-40 bg-slate-950/45 backdrop-blur-sm transition lg:hidden",
            menuOpen ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"
          )}
          onClick={() => setMenuOpen(false)}
        />

        <aside
          className={cn(
            "fixed inset-y-0 left-0 z-50 flex w-[86vw]  flex-col border-r border-slate-800 bg-slate-950 text-white shadow-2xl transition-transform lg:sticky lg:top-0 lg:h-screen lg:w-auto lg:max-w-none lg:translate-x-0 lg:border-b-0 lg:shadow-none",
            menuOpen ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <div className="mb-4 flex items-center justify-between lg:hidden">
            <span className="text-sm font-medium text-slate-200">Navigation</span>
            <Button
              variant="ghost"
              size="sm"
              className="rounded-full px-2 text-white hover:bg-white/10"
              onClick={() => setMenuOpen(false)}
              aria-label="Close menu"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="grid flex-1 content-between gap-6 overflow-y-auto p-2">
            <div className="grid gap-6">
              <div className="inline-flex w-fit max-w-full items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] font-medium uppercase tracking-[0.16em] text-slate-300">
                <School className="h-4 w-4" />
                <span>{schoolName}</span>
              </div>
              {/* <div className="grid gap-2">
                <h1 className="text-xl font-semibold tracking-tight text-white">VidyaStack ERP</h1>
                <p className="max-w-xs text-sm leading-6 text-slate-400">
                  Simple daily operations for school staff, finance, and academic records.
                </p>
              </div> */}
            </div>

            <nav className="grid gap-1.5" aria-label="Primary navigation">
              
              {NAV_ITEMS.map((item) => {
                const Icon = navIconMap[item.href] ?? LayoutDashboard;
                const active =
                  item.href === "/dashboard"
                    ? pathname === item.href
                    : pathname.startsWith(item.href);

                return item.disabled ? (
                  <span
                    key={item.href}
                    className="flex cursor-not-allowed items-center gap-3 rounded-lg border border-white/5 bg-white/[0.04] px-3 py-2.5 text-sm text-slate-500"
                    aria-disabled="true"
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </span>
                ) : (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "flex items-center gap-3 rounded-lg border px-3 py-2.5 text-sm font-medium transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white/50",
                      active
                        ? "border-white/10 bg-white text-slate-950 shadow-lg shadow-black/10"
                        : "border-transparent bg-white/[0.04] text-slate-100 hover:bg-white/[0.1]"
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </Link>
                );
              })}
            </nav>

            {/* <div className="grid gap-3 rounded-lg border border-white/10 bg-white/[0.045] p-3 text-sm text-slate-300">
              <div className="flex items-center gap-2 text-white">
                <Shield className="h-4 w-4" />
                <span className="font-medium">{roleSummary}</span>
              </div>
              <div className="flex items-start gap-2">
                <MonitorSmartphone className="mt-0.5 h-4 w-4 shrink-0" />
                <span>Ready for desktop, tablet, and low-tech staff workflows on the school LAN.</span>
              </div>
            </div> */}
          </div>
        </aside>

        <div className="grid min-w-0">
          <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
            <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6 lg:px-7">
              <div className="flex min-w-0 items-center gap-3">
                <Button
                  variant="secondary"
                  size="sm"
                  className="rounded-full px-2.5 lg:hidden"
                  onClick={() => setMenuOpen(true)}
                  aria-label="Open menu"
                >
                  <Menu className="h-4 w-4" />
                </Button>
                <div className="min-w-0">
                  <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">
                    {currentItem.label}
                  </p>
                  <p className="truncate text-base font-semibold text-slate-950">
                    {schoolName}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="hidden rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-right sm:block">
                  <p className="text-xs text-slate-500">Signed in as</p>
                  <p className="text-sm font-medium text-slate-900">{userLabel}</p>
                </div>
                <Button variant="secondary" size="sm" className="px-3">
                  <Bell className="h-4 w-4" />
                  Alerts
                </Button>
                <form action={logoutAction}>
                  <Button variant="secondary" size="sm" className="px-3">
                    <LogOut className="h-4 w-4" />
                    Sign out
                  </Button>
                </form>
              </div>
            </div>
          </header>
          <main className="w-full min-w-0 px-4 py-5 sm:px-6 lg:px-7 lg:py-6">{children}</main>
        </div>
      </div>
    </div>
  );
}

const navIconMap: Record<string, typeof LayoutDashboard> = {
  "/dashboard": LayoutDashboard,
  "/dashboard/profile": UserRound,
  "/dashboard/staff": UserCog,
  "/dashboard/users": UserCog,
  "/dashboard/students": Users,
  "/dashboard/documents": FileText,
  "/dashboard/attendance": CalendarCheck2,
  "/dashboard/fees": IndianRupee,
  "/dashboard/exams": BookOpenCheck,
  "/dashboard/notices": ClipboardList,
  "/dashboard/reports": FileText,
  "/dashboard/audit": History,
  "/dashboard/settings": Settings2
};
